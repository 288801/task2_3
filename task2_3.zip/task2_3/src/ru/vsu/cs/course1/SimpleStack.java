package ru.vsu.cs.course1;

import java.util.Iterator;

public class SimpleStack<T> {
//    class SimpleStackNode {
//        public T value;
//        public SimpleStackNode next;
//
//        public SimpleStackNode(int value, SimpleStackNode next) {
//            this.value = value;
//            this.next = next;
//        }
//
//        public SimpleStackNode(int value) {
//            this(value, null);
//        }
//    }
//    private SimpleStackNode first = null;  // first, top
//    private int size = 0;
//
//
//    public int peek() {
//        return size() == 0 ? null : first.value;
//    }
//
//    public T pop() {
//        T first = null;
//        if (this.size() > 0) {
//            first = first.value;
//            this.first = first.next;
//            size--;
//        }
//        return first;
//    }
//
//    public int size() {
//        return size;
//    }
//
//    @Override
//    public Iterator<T> iterator() {
//        class SimpleLinkedListIterator implements Iterator<Integer> {
//            SimpleStack curr = first;
//
//            @Override
//            public boolean hasNext() {
//                return curr != null;
//            }
//
//            @Override
//            public Integer next() {
//                int value = curr.value;
//                curr = curr.next;
//                return value;
//            }
//        }
//
//        return (Iterator<T>) new SimpleLinkedListIterator();
//    }

    public Node first;
    public int size;

    private class Node {
        public Node next;
        public T value;

        Node(T value) {
            this.value = value;
        }
    }

    public void push(T value) {
        if (size == 0) {
            first = new Node(value);
        } else {
            Node last = null;
            for (Node node = first; node != null; node = node.next) {
                last = node;
            }
            if (last == null) {
                Node head = new Node(value);
                first.next = first;
                first = head;
            } else {
                Node temp = last.next;
                last.next = new Node(value);
                last.next.next = temp;
            }
        }
        this.size++;
    }

    public T peek() {
        return size() == 0 ? null : first.value;
    }

    public T pop() {
        T head = null;
        if (this.size() > 0) {
            head = first.value;
            first = first.next;
            size--;
        }
        return head;
    }

    public int size() {
        return this.size;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder("[");
        int count = 0;
        for (Node node = this.first; node != null; node = node.next) {
            sb.append(node.value);
            if (count++ < this.size() - 1) {
                sb.append(", ");
            }
        }
        return sb.append("]").toString();
    }

}

