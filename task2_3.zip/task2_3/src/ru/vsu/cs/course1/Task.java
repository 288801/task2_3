package ru.vsu.cs.course1;


import java.util.Stack;

public class Task {

    public static SimpleStack<String> sol2(String[] arr){
        SimpleStack<String> stack = new SimpleStack<>();
        SimpleStack<String> newStack = new SimpleStack<>();

        for(int k = 0; k < arr.length; k++){     //заполнение стека
            stack.push(arr[arr.length-1-k]);
        }

        for (int n = 0; n < arr.length; n++) {
            newStack.push(stack.pop());
        }

        return newStack;
    }

    public static Stack<String> sol(String[] arr){
        Stack<String> stack = new Stack<>();
        Stack<String> newStack = new Stack<>();

        for(int k = 0; k < arr.length; k++){     //заполнение стека
            stack.push(arr[arr.length-1-k]);
        }

        for (int n = 0; n < arr.length; n++) {
            newStack.push(stack.pop());
        }

        return newStack;
    }
}
